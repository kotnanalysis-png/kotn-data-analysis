# KOTN Read-only Bid Research Collector

Collects public catalogue summaries and available per-listing bid histories. **Does not place bids, log in, reuse authentication tokens, or bypass access controls.** SQLite is the durable store, with CSV exports and a basic activity summary.

## Install (Windows PowerShell)

```powershell
py -m pip install requests beautifulsoup4
```

## Try the first two 90-item catalogue pages

```powershell
py .\kotn_scraper.py scan --start-page 1 --pages 2
py .\kotn_scraper.py histories --limit 30
py .\kotn_scraper.py analyze
py .\kotn_scraper.py export
```

This creates `kotn.sqlite`, `kotn_listings.csv`, and `kotn_bids.csv` in your working directory. `histories` processes records not yet checked; use `--refresh` to revisit existing records.

## Collect additional pages

```powershell
py .\kotn_scraper.py scan --start-page 3 --pages 10 --delay 4
py .\kotn_scraper.py histories --limit 100 --delay 4
```

The collector defaults to at least 3 seconds per request, serial requests, retry backoff, and a robots.txt permission check. It stops if robots rules disallow access or login is required. Only use `--allow-unchecked-robots` if you have confirmed that automated read-only collection is permitted and robots.txt simply cannot be retrieved. Respect HTTP rate limits and site instructions.

## Import previously saved HTML without accessing the website

```powershell
py .\kotn_scraper.py import-html "saved-catalogue.html" "saved-listing.html"
```

**Caution:** The original HTML you saved while logged in includes API and CSRF tokens. Keep originals private; this scraper extracts only listing and bid data into its database, not the tokens.

## Data model

`listings` table: listing ID, title, current bid, leading bidder, scheduled end, open/closed state, last observation, history-checked time.

`bids` table: unique bid ID, listing ID, bidder username, amount, timestamp. BID IDs are deduplicated across page visits.

Bid history available to the public may disappear after closing, so collect while pages are accessible. A saved page snapshot cannot guarantee the history remains complete through final close. Some pages may show no historical bids even if items have ended.

The `analyze` output is exploratory and does **not** determine who operates a bot or prove shill bidding. Faster-than-human sequences should be examined with data completeness and timing uncertainty in mind.
